#!/data/data/com.yato.fl_ide/files/usr/bin/sh

echo "$@"
