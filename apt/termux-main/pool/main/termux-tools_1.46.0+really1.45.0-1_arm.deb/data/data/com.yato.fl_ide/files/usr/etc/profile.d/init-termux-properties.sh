if [ ! -f /data/data/com.yato.fl_ide/files/home/.config/termux/termux.properties ] && [ ! -e /data/data/com.yato.fl_ide/files/home/.termux/termux.properties ]; then
	mkdir -p /data/data/com.yato.fl_ide/files/home/.termux
	cp /data/data/com.yato.fl_ide/files/usr/share/examples/termux/termux.properties /data/data/com.yato.fl_ide/files/home/.termux/
fi
