#!/data/data/com.yato.fl_ide/files/usr/bin/bash

# Setup TERMUX_APP_PACKAGE_MANAGER
source "/data/data/com.yato.fl_ide/files/usr/bin/termux-setup-package-manager" || exit 1

terminal_width="$(stty size | cut -d" " -f2)"
motd="
\e[1mWelcome to Code on the Go Terminal!\e[0m

\e[1mHere's what you need to know:\e[0m
 - Type '\e[1mls\e[0m' to see files and folders
 - Type '\e[1mpwd\e[0m' to see where you are
 - Type '\e[1mcd <folder>\e[0m' to enter a folder
 - Type '\e[1mcd ..\e[0m' to go back one folder
 - Type '\e[1mexit\e[0m' to leave the terminal

\e[1mNeed help with any command?\e[0m Type '\e[1mman <command>\e[0m' or '\e[1m<command> --help\e[0m'

\e[1mWorking with packages:\e[0m
\e[1m - Search :\e[0m  apt search <query>
\e[1m - Install:\e[0m  apt-get install <package>
\e[1m - Upgrade:\e[0m  apt-get update && apt-get upgrade

\e[1mQuick Tips:\e[0m
 - Use \e[1mTab\e[0m to auto-complete commands and filenames
 - Use \e[1mUp/Down arrows\e[0m to cycle through command history
 - Press \e[1mCtrl+C\e[0m to stop a running command
 - Press \e[1mCtrl+L\e[0m to clear the screen

\e[1mLearn more:\e[0m
 - Terminal basics:     \e[4mhttps://ubuntu.com/tutorials/command-line-for-beginners\e[0m
 - Package management:  \e[4mhttps://help.ubuntu.com/community/AptGet/Howto\e[0m

\e[1mReport issues at\e[0m \e[4mhttps://github.com/appdevforall/CodeOnTheGo/issues\e[0m

"
echo -e "$motd"