##
## This script is sourced by /data/data/com.yato.fl_ide/files/usr/bin/login before executing shell.
##
